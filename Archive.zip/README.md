# One Vision — Branch 360 (App 2)

A branch-level consulting dashboard built on the six contest files in `Data/`, with a left navigation rail:
Landing → pick a branch → Branch 360: health score, balanced scorecard, SWOT,
BCG, GE–McKinsey nine-box, Ansoff, strategy canvas, Pareto, momentum, peers and
a consultant's memo. "Compare two branches" is the next build.

Run it:   python3 ai_server.py   then open http://localhost:8788
(Opening index.html directly also works; only the AI memo needs the server.)

Rebuild data:  python3 pipeline/build.py split
               python3 pipeline/build.py sales credit ops ins risk coll   (repeat until nothing is pending)
               python3 pipeline/build.py assemble
